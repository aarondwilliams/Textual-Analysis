Textual Analysis Midterm
Aaron Williams - 10/9/2018

This python code shouldn't require anything but numpy and nltk.brown.
Run the algorithm and it will print out the results shown in the report.